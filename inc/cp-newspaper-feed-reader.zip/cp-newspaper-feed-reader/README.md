# cp-newspaper-feed-reader
Syndicate content from various sources. A [ContentPress](https://github.com/wp-kitten/contentpress) Plugin.
