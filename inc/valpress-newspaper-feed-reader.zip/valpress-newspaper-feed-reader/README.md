# cp-newspaper-feed-reader
Syndicate content from various sources. A [ValPress](https://github.com/wp-kitten/valpress) Plugin.
